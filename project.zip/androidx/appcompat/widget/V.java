package androidx.appcompat.widget;

import android.widget.ThemedSpinnerAdapter;

public final class v {
    public static boolean a(Object object0) {
        return object0 instanceof ThemedSpinnerAdapter;
    }
}


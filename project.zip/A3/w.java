package A3;

import kotlin.h0;
import kotlin.jvm.internal.E;
import kotlin.v;
import y4.l;

@h0(version = "1.3")
public interface w extends E, v {
    @Override  // kotlin.jvm.internal.E
    int getArity();

    Object q1(@l Object[] arg1);
}


package A3;

import kotlin.v;

public interface q extends v {
    Object T0(Object arg1, Object arg2, Object arg3, Object arg4);
}


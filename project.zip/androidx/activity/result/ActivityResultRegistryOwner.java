package androidx.activity.result;

import y4.l;

public interface ActivityResultRegistryOwner {
    @l
    ActivityResultRegistry getActivityResultRegistry();
}


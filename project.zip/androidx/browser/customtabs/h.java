package androidx.browser.customtabs;

import android.os.Bundle;
import androidx.annotation.IntRange;
import androidx.annotation.NonNull;

public final class h {
    public static void a(EngagementSignalsCallback engagementSignalsCallback0, @IntRange(from = 1L, to = 100L) int v, @NonNull Bundle bundle0) {
    }

    public static void b(EngagementSignalsCallback engagementSignalsCallback0, boolean z, @NonNull Bundle bundle0) {
    }

    public static void c(EngagementSignalsCallback engagementSignalsCallback0, boolean z, @NonNull Bundle bundle0) {
    }
}


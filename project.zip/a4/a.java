package A4;

import org.slf4j.d;

public interface a extends org.slf4j.a {
    public static final int R = 0;
    public static final int S = 10;
    public static final int T = 20;
    public static final int U = 30;
    public static final int V = 40;

    void a0(d arg1, String arg2, int arg3, String arg4, Object[] arg5, Throwable arg6);
}


package android.support.v4.media.session;

import android.content.Context;
import android.media.session.MediaSession;
import android.os.Bundle;

public final class l {
    public static MediaSession a(Context context0, String s, Bundle bundle0) {
        return new MediaSession(context0, s, bundle0);
    }
}


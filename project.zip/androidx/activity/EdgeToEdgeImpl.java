package androidx.activity;

import android.view.View;
import android.view.Window;
import y4.l;

interface EdgeToEdgeImpl {
    void a(@l Window arg1);

    void b(@l SystemBarStyle arg1, @l SystemBarStyle arg2, @l Window arg3, @l View arg4, boolean arg5, boolean arg6);
}


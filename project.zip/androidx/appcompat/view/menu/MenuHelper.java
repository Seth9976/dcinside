package androidx.appcompat.view.menu;

interface MenuHelper {
    void a(Callback arg1);

    void dismiss();
}


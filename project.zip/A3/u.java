package A3;

import kotlin.v;

public interface u extends v {
    Object U0(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8);
}


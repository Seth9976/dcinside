package androidx.browser.customtabs;

import androidx.annotation.RequiresOptIn.Level;
import androidx.annotation.RequiresOptIn;

@RequiresOptIn(level = Level.a)
public @interface ExperimentalMinimizationCallback {
}


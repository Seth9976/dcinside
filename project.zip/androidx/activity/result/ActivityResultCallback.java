package androidx.activity.result;

public interface ActivityResultCallback {
    void a(Object arg1);
}


package androidx.appcompat.app;

import androidx.annotation.Nullable;
import androidx.appcompat.view.ActionMode.Callback;
import androidx.appcompat.view.ActionMode;

public interface AppCompatCallback {
    void S(ActionMode arg1);

    void r(ActionMode arg1);

    @Nullable
    ActionMode s(Callback arg1);
}


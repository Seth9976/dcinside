package androidx.appcompat.view;

@Deprecated
public interface CollapsibleActionView {
    void b();

    void c();
}


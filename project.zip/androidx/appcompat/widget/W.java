package androidx.appcompat.widget;

import android.widget.ThemedSpinnerAdapter;

public final class w {
    public static ThemedSpinnerAdapter a(Object object0) [...] // Inlined contents
}


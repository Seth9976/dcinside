package androidx.appcompat.app;

import android.window.OnBackInvokedCallback;

public final class l {
    public static OnBackInvokedCallback a(Object object0) [...] // Inlined contents
}


package A3;

import kotlin.v;

public interface s extends v {
    Object invoke(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6);
}


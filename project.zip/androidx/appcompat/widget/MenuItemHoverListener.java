package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo.Scope;
import androidx.annotation.RestrictTo;
import androidx.appcompat.view.menu.MenuBuilder;

@RestrictTo({Scope.c})
public interface MenuItemHoverListener {
    void c(@NonNull MenuBuilder arg1, @NonNull MenuItem arg2);

    void i(@NonNull MenuBuilder arg1, @NonNull MenuItem arg2);
}


package A3;

import kotlin.v;

public interface p extends v {
    Object invoke(Object arg1, Object arg2, Object arg3);
}


package A3;

import kotlin.v;

public interface t extends v {
    Object d1(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7);
}


package A3;

import kotlin.v;

public interface r extends v {
    Object K0(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5);
}


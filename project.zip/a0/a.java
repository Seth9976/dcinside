package A0;

import android.graphics.Bitmap.Config;
import android.graphics.Bitmap;
import k1.n.a;
import k1.n;

@n(a.a)
public interface A0.a {
    Bitmap a(int arg1, int arg2, Bitmap.Config arg3);
}


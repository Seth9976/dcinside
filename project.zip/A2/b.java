package A2;

import android.webkit.WebView;
import java.lang.ref.WeakReference;

public class b extends WeakReference {
    public b(WebView webView0) {
        super(webView0);
    }
}


package A4;

import org.slf4j.ILoggerFactory;

public interface b {
    ILoggerFactory a();

    String b();
}


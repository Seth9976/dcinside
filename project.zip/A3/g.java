package a3;

public interface g {
    void a(Object arg1);
}


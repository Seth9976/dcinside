package a2;

public interface a {
    void b();
}


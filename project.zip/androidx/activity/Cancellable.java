package androidx.activity;

public interface Cancellable {
    void cancel();
}


package a3;

public interface e {
    Object get();
}


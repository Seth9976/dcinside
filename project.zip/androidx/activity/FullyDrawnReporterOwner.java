package androidx.activity;

import y4.l;

public interface FullyDrawnReporterOwner {
    @l
    FullyDrawnReporter getFullyDrawnReporter();
}


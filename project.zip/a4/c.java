package A4;

import org.slf4j.IMarkerFactory;

public interface c {
    IMarkerFactory a();

    String b();
}


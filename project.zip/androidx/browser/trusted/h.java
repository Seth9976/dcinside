package androidx.browser.trusted;

import android.app.NotificationChannel;

public final class h {
    public static NotificationChannel a(String s, CharSequence charSequence0, int v) {
        return new NotificationChannel(s, charSequence0, v);
    }
}


package A1;

import androidx.annotation.Nullable;

public interface c {
    @Nullable
    Object a(Object arg1, Object arg2);
}


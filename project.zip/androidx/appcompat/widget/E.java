package androidx.appcompat.widget;

import android.view.inspector.InspectionCompanion.UninitializedPropertyMapException;

public final class e {
    public static InspectionCompanion.UninitializedPropertyMapException a() {
        return new InspectionCompanion.UninitializedPropertyMapException();
    }
}


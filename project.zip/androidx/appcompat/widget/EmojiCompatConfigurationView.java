package androidx.appcompat.widget;

public interface EmojiCompatConfigurationView {
    boolean a();

    void setEmojiCompatEnabled(boolean arg1);
}


package a3;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import r3.e;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@e
public @interface j {
}


package androidx.activity.contextaware;

import android.content.Context;
import y4.l;

public interface OnContextAvailableListener {
    void a(@l Context arg1);
}


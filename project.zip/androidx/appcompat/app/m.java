package androidx.appcompat.app;

import android.window.OnBackInvokedDispatcher;

public final class m {
    public static OnBackInvokedDispatcher a(Object object0) [...] // Inlined contents
}


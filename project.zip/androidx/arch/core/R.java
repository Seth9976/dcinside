package androidx.arch.core;

public final class R {
}


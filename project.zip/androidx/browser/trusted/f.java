package androidx.browser.trusted;

public final class f {
}


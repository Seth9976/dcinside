package A3;

public interface v extends kotlin.v {
    Object C1(Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6, Object arg7, Object arg8, Object arg9);
}

